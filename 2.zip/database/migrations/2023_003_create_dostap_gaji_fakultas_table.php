<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('dostap_gaji_fakultas', function (Blueprint $table) {
            $table->id();
            $table->integer('tj_tambahan')->nullable();
            $table->integer('honor_kinerja')->nullable();
            $table->integer('honor_klb_mengajar')->nullable();
            $table->integer('honor_mengajar_DPK')->nullable();
            $table->integer('peny_honor_mengajar')->nullable();
            $table->integer('tj_guru_besar')->nullable();
            $table->integer('honor')->nullable();
            $table->integer('total_gaji_fakultas')->nullable();
            $table->unsignedBigInteger('dosen_tetap_id');
            $table->softDeletes();
            $table->timestamps();

        });
            Schema::table('dostap_gaji_fakultas', function(Blueprint $table){
            $table->foreign('dosen_tetap_id')->references('id')->on('dosen_tetap');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('dostap_gaji_fakultas');
    }
};
